﻿namespace Assingnment_3.Model
{
    
        public class Students

        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string qualification { get; set; }
            public string skill { get; set; }
        }
    }




