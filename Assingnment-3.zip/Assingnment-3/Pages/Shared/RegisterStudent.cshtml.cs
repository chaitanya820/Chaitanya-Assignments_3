
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Assingnment_3.Model;

namespace Assingnment_3.Model
{
    public class StudentModel : PageModel
    {
        static List<Students> = new List<Students>();
        public List<Students> List
        {
            get { return s; }
        }
        public void OnGet()
        {
        }
        [BindProperty]
        public Students student { get; set; }
        public IActionResult OnPost()
        {
            s.Add(student);
            return RedirectToPage("Student");
        }
    }
}






